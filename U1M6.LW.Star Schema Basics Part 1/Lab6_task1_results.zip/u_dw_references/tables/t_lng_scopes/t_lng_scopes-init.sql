--Initial rows
INSERT INTO u_dw_references.t_lng_scopes ( lng_scope_id
                         , lng_scope_code )
     VALUES ( 1
            , 'I' );

INSERT INTO u_dw_references.t_lng_scopes ( lng_scope_id
                         , lng_scope_code )
     VALUES ( 2
            , 'M' );

INSERT INTO u_dw_references.t_lng_scopes ( lng_scope_id
                         , lng_scope_code )
     VALUES ( 3
            , 'S' );

Commit;            