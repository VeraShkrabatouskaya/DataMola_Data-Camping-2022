drop sequence u_dw_references.sq_lng_scopes_t_id;

create sequence u_dw_references.sq_lng_scopes_t_id
start with 4;

grant SELECT on u_dw_references.sq_lng_scopes_t_id to u_dw_ext_references;

